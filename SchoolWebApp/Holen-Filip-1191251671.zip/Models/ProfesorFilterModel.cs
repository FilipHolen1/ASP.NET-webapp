﻿namespace SchoolWebApp.Web.Models
{
    public class ProfesorFilterModel
    {
        public string FullName { get; set; }
        public string Email { get; set; }
    }
}
