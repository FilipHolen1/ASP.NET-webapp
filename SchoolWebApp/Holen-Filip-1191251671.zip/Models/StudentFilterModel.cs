﻿namespace SchoolWebApp.Web.Models
{
    public class StudentFilterModel
    {
        public string FullName { get; set; }
        public string Email { get; set; } 
    }
}
