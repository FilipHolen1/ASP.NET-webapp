﻿using Microsoft.AspNetCore.Mvc;

namespace SchoolWebApp.Web.Views.Profesor
{
    public class ProfesorFilter : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
